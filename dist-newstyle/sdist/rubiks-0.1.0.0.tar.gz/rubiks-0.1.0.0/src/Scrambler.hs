{-
generate a random state scramble - I use 30 rotations as a default as I check for non-valid rotations.

code makes sure there are no self cancelling rotations .. eg .. "R" cannot be followed by "R'"

no consecutive opposites rotations .. eg .. "L" cannot be followed by "R" ... "U" cannot be followed by "D".

double rotations are allowed but no more than 3 or it becomes a prime move while rule 3 applies.

once it is scrambled and we have a "state" - we pass it through Kociemba algorithm to solve it ..

once solved - that solution string becomes a SCRAMBLE!

-}



module Scrambler (scramble) where

scramble :: IO ()
scramble = putStrLn "Scrambeling something..."