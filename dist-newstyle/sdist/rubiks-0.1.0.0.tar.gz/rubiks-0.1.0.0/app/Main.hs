module Main where

import System.Environment (getArgs)
import qualified Scrambler (scramble)

main :: IO ()
main = do
  args <- getArgs


  case args of 
    ("scramble" : _) -> Scrambler.scramble
    _ -> putStrLn "Cound not find command"
